#include <cstring>

using namespace std;

struct hours {
	string day;
	string open_hour;
	string close_hour;
};
