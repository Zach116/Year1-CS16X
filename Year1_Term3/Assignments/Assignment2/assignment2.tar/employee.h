#include <cstring>

using namespace std;

struct employee {
	string id;
	string first_name;
	string last_name;
	string password;
};
