#ifndef TENANT_H
#define TENANT_H

#include <iostream>

using namespace std;

struct tenant {
	int rent;
	int budget;
	int agreeability;
};

#endif
