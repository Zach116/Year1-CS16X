#ifndef TOOLS_H
#define TOOLS_H

#include <iostream>
#include <stdlib.h>
#include <cstring>
#include <fstream>
#include <cmath>
#include <string>

using namespace std;

void add_one_char(char** str, char c);
char* get_input();
bool is_int (char* num);
bool is_int (string num);
int get_int(char* prompt);
int get_int(string prompt);
string lowercase(string word);

#endif
